module.exports = client => {
  console.log(`Restarting, Reis ${new Date()}`);
};
