﻿var _0x4bd5 = ["discord.js", "chalk", "fs", "./RoomID.json", "moment", "./util/eventLoader", "colors", "prefix", "commands", "aliases", "./general/", "log", "pop", ".", "split", "js", "filter", "length", "An error occu.red!", "exit", "", "\x54\x68\xEA\x6D\x20\x56\xE0\x6F\x20", "name", "help", "set", "forEach", "readdir", "reload", "resolve", "cache", "delete", "conf", "load", "unload", "./attack_layer4/", "./attack_layer7/", "elevation", "guild", "BAN_MEMBERS", "hasPermission", "member", "ADMINISTRATOR", "id", "author", "sahip", "ready", "gray", " ██▒   █▓ ██▓ ██▀███  ▄▄▄█████▓ █    ██  ▄▄▄       ██▓     ██▓▒███████▒ ▄▄▄     ▄▄▄█████▓ ██▓ ▒█████   ███▄    █ ", "▓██░   █▒▓██▒▓██ ▒ ██▒▓  ██▒ ▓▒ ██  ▓██▒▒████▄    ▓██▒    ▓██▒▒ ▒ ▒ ▄▀░▒████▄   ▓  ██▒ ▓▒▓██▒▒██▒  ██▒ ██ ▀█   █ ", "▓██  █▒░▒██▒▓██ ░▄█ ▒▒ ▓██░ ▒░▓██  ▒██░▒██  ▀█▄  ▒██░    ▒██▒░ ▒ ▄▀▒░ ▒██  ▀█▄ ▒ ▓██░ ▒░▒██▒▒██░  ██▒▓██  ▀█ ██▒", " ▒██ █░░░██░▒██▀▀█▄  ░ ▓██▓ ░ ▓▓█  ░██░░██▄▄▄▄██ ▒██░    ░██░  ▄▀▒   ░░██▄▄▄▄██░ ▓██▓ ░ ░██░▒██   ██░▓██▒  ▐▌██▒", "  ▒▀█░  ░██░░██▓ ▒██▒  ▒██▒ ░ ▒▒█████▓  ▓█   ▓██▒░██████▒░██░▒███████▒ ▓█   ▓██▒ ▒██▒ ░ ░██░░ ████▓▒░▒██░   ▓██░", "  ░ ▐░  ░▓  ░ ▒▓ ░▒▓░  ▒ ░░   ░▒▓▒ ▒ ▒  ▒▒   ▓▒█░░ ▒░▓  ░░▓  ░▒▒ ▓░▒░▒ ▒▒   ▓▒█░ ▒ ░░   ░▓  ░ ▒░▒░▒░ ░ ▒░   ▒ ▒ ", "  ░ ░░   ▒ ░  ░▒ ░ ▒░    ░    ░░▒░ ░ ░   ▒   ▒▒ ░░ ░ ▒  ░ ▒ ░░░▒ ▒ ░ ▒  ▒   ▒▒ ░   ░     ▒ ░  ░ ▒ ▒░ ░ ░░   ░ ▒░", "    ░░   ▒ ░  ░░   ░   ░       ░░░ ░ ░   ░   ▒     ░ ░    ▒ ░░ ░ ░ ░ ░  ░   ▒    ░       ▒ ░░ ░ ░ ▒     ░   ░ ░ ", "     ░   ░     ░                 ░           ░  ░    ░  ░ ░    ░ ░          ░  ░         ░      ░ ░           ░ ", "    ░                                                        ░                                                  ", "on", "available", "Đang Xem Sẽ", "WATCHING", "https://discord.com/", "setPresence", "user", "once", "warn", "that was.redacted", "replace", "red", "b", "error", "", "login"];
const Discord = require(_0x4bd5[0]);
const {
    Client
} = require(_0x4bd5[0]);
const client = new Discord.Client();
const chalk = require(_0x4bd5[1]);
const fs = require(_0x4bd5[2]);
const ayarlar = require(_0x4bd5[3]);
const moment = require(_0x4bd5[4]);
require(_0x4bd5[5])(client);
var colors = require(_0x4bd5[6]);
var prefix = ayarlar[_0x4bd5[7]];
client[_0x4bd5[8]] = new Discord.Collection();
client[_0x4bd5[9]] = new Discord.Collection();
fs[_0x4bd5[26]](_0x4bd5[10], (_0x9485x9, _0x9485xa) => {
    if (_0x9485x9) {
        console[_0x4bd5[11]](_0x9485x9)
    };
    let _0x9485xb = _0x9485xa[_0x4bd5[16]]((_0x9485xc) => {
        return _0x9485xc[_0x4bd5[14]](_0x4bd5[13])[_0x4bd5[12]]() === _0x4bd5[15]
    });
    if (_0x9485xb[_0x4bd5[17]] <= 0) {
        console[_0x4bd5[11]](new Error(_0x4bd5[18]));
        process[_0x4bd5[19]](1);
        return
    };
    _0x9485xb[_0x4bd5[25]]((_0x9485xc) => {
        let _0x9485xd = require(`${_0x4bd5[10]}${_0x9485xc}${_0x4bd5[20]}`);
        console[_0x4bd5[11]](`${_0x4bd5[21]}${_0x9485xc}${_0x4bd5[13]}`);
        client[_0x4bd5[8]][_0x4bd5[24]](_0x9485xd[_0x4bd5[23]][_0x4bd5[22]], _0x9485xd)
    })
});
client[_0x4bd5[27]] = (_0x9485xe) => {
    return new Promise((_0x9485xf, _0x9485x10) => {
        try {
            delete require[_0x4bd5[29]][require[_0x4bd5[28]](`${_0x4bd5[10]}${_0x9485xe}${_0x4bd5[20]}`)];
            let _0x9485x11 = require(`${_0x4bd5[10]}${_0x9485xe}${_0x4bd5[20]}`);
            client[_0x4bd5[8]][_0x4bd5[30]](_0x9485xe);
            client[_0x4bd5[9]][_0x4bd5[25]]((_0x9485x11, _0x9485x12) => {
                if (_0x9485x11 === _0x9485xe) {
                    client[_0x4bd5[9]][_0x4bd5[30]](_0x9485x12)
                }
            });
            client[_0x4bd5[8]][_0x4bd5[24]](_0x9485xe, _0x9485x11);
            _0x9485x11[_0x4bd5[31]][_0x4bd5[9]][_0x4bd5[25]]((_0x9485x12) => {
                client[_0x4bd5[9]][_0x4bd5[24]](_0x9485x12, _0x9485x11[_0x4bd5[23]][_0x4bd5[22]])
            });
            _0x9485xf()
        } catch (e) {
            _0x9485x10(e)
        }
    })
};
client[_0x4bd5[32]] = (_0x9485xe) => {
    return new Promise((_0x9485xf, _0x9485x10) => {
        try {
            let _0x9485x11 = require(`${_0x4bd5[10]}${_0x9485xe}${_0x4bd5[20]}`);
            client[_0x4bd5[8]][_0x4bd5[24]](_0x9485xe, _0x9485x11);
            _0x9485x11[_0x4bd5[31]][_0x4bd5[9]][_0x4bd5[25]]((_0x9485x12) => {
                client[_0x4bd5[9]][_0x4bd5[24]](_0x9485x12, _0x9485x11[_0x4bd5[23]][_0x4bd5[22]])
            });
            _0x9485xf()
        } catch (e) {
            _0x9485x10(e)
        }
    })
};
client[_0x4bd5[33]] = (_0x9485xe) => {
    return new Promise((_0x9485xf, _0x9485x10) => {
        try {
            delete require[_0x4bd5[29]][require[_0x4bd5[28]](`${_0x4bd5[10]}${_0x9485xe}${_0x4bd5[20]}`)];
            let _0x9485x11 = require(`${_0x4bd5[10]}${_0x9485xe}${_0x4bd5[20]}`);
            client[_0x4bd5[8]][_0x4bd5[30]](_0x9485xe);
            client[_0x4bd5[9]][_0x4bd5[25]]((_0x9485x11, _0x9485x12) => {
                if (_0x9485x11 === _0x9485xe) {
                    client[_0x4bd5[9]][_0x4bd5[30]](_0x9485x12)
                }
            });
            _0x9485xf()
        } catch (e) {
            _0x9485x10(e)
        }
    })
};
fs[_0x4bd5[26]](_0x4bd5[34], (_0x9485x9, _0x9485xa) => {
    if (_0x9485x9) {
        console[_0x4bd5[11]](_0x9485x9)
    };
    let _0x9485xb = _0x9485xa[_0x4bd5[16]]((_0x9485xc) => {
        return _0x9485xc[_0x4bd5[14]](_0x4bd5[13])[_0x4bd5[12]]() === _0x4bd5[15]
    });
    if (_0x9485xb[_0x4bd5[17]] <= 0) {
        console[_0x4bd5[11]](new Error(_0x4bd5[18]));
        process[_0x4bd5[19]](1);
        return
    };
    _0x9485xb[_0x4bd5[25]]((_0x9485xc) => {
        let _0x9485xd = require(`${_0x4bd5[34]}${_0x9485xc}${_0x4bd5[20]}`);
        console[_0x4bd5[11]](`${_0x4bd5[21]}${_0x9485xc}${_0x4bd5[13]}`);
        client[_0x4bd5[8]][_0x4bd5[24]](_0x9485xd[_0x4bd5[23]][_0x4bd5[22]], _0x9485xd)
    })
});
client[_0x4bd5[27]] = (_0x9485xe) => {
    return new Promise((_0x9485xf, _0x9485x10) => {
        try {
            delete require[_0x4bd5[29]][require[_0x4bd5[28]](`${_0x4bd5[34]}${_0x9485xe}${_0x4bd5[20]}`)];
            let _0x9485x11 = require(`${_0x4bd5[34]}${_0x9485xe}${_0x4bd5[20]}`);
            client[_0x4bd5[8]][_0x4bd5[30]](_0x9485xe);
            client[_0x4bd5[9]][_0x4bd5[25]]((_0x9485x11, _0x9485x12) => {
                if (_0x9485x11 === _0x9485xe) {
                    client[_0x4bd5[9]][_0x4bd5[30]](_0x9485x12)
                }
            });
            client[_0x4bd5[8]][_0x4bd5[24]](_0x9485xe, _0x9485x11);
            _0x9485x11[_0x4bd5[31]][_0x4bd5[9]][_0x4bd5[25]]((_0x9485x12) => {
                client[_0x4bd5[9]][_0x4bd5[24]](_0x9485x12, _0x9485x11[_0x4bd5[23]][_0x4bd5[22]])
            });
            _0x9485xf()
        } catch (e) {
            _0x9485x10(e)
        }
    })
};
client[_0x4bd5[32]] = (_0x9485xe) => {
    return new Promise((_0x9485xf, _0x9485x10) => {
        try {
            let _0x9485x11 = require(`${_0x4bd5[34]}${_0x9485xe}${_0x4bd5[20]}`);
            client[_0x4bd5[8]][_0x4bd5[24]](_0x9485xe, _0x9485x11);
            _0x9485x11[_0x4bd5[31]][_0x4bd5[9]][_0x4bd5[25]]((_0x9485x12) => {
                client[_0x4bd5[9]][_0x4bd5[24]](_0x9485x12, _0x9485x11[_0x4bd5[23]][_0x4bd5[22]])
            });
            _0x9485xf()
        } catch (e) {
            _0x9485x10(e)
        }
    })
};
client[_0x4bd5[33]] = (_0x9485xe) => {
    return new Promise((_0x9485xf, _0x9485x10) => {
        try {
            delete require[_0x4bd5[29]][require[_0x4bd5[28]](`${_0x4bd5[34]}${_0x9485xe}${_0x4bd5[20]}`)];
            let _0x9485x11 = require(`${_0x4bd5[34]}${_0x9485xe}${_0x4bd5[20]}`);
            client[_0x4bd5[8]][_0x4bd5[30]](_0x9485xe);
            client[_0x4bd5[9]][_0x4bd5[25]]((_0x9485x11, _0x9485x12) => {
                if (_0x9485x11 === _0x9485xe) {
                    client[_0x4bd5[9]][_0x4bd5[30]](_0x9485x12)
                }
            });
            _0x9485xf()
        } catch (e) {
            _0x9485x10(e)
        }
    })
};
fs[_0x4bd5[26]](_0x4bd5[35], (_0x9485x9, _0x9485xa) => {
    if (_0x9485x9) {
        console[_0x4bd5[11]](_0x9485x9)
    };
    let _0x9485xb = _0x9485xa[_0x4bd5[16]]((_0x9485xc) => {
        return _0x9485xc[_0x4bd5[14]](_0x4bd5[13])[_0x4bd5[12]]() === _0x4bd5[15]
    });
    if (_0x9485xb[_0x4bd5[17]] <= 0) {
        console[_0x4bd5[11]](new Error(_0x4bd5[18]));
        process[_0x4bd5[19]](1);
        return
    };
    _0x9485xb[_0x4bd5[25]]((_0x9485xc) => {
        let _0x9485xd = require(`${_0x4bd5[35]}${_0x9485xc}${_0x4bd5[20]}`);
        console[_0x4bd5[11]](`${_0x4bd5[21]}${_0x9485xc}${_0x4bd5[13]}`);
        client[_0x4bd5[8]][_0x4bd5[24]](_0x9485xd[_0x4bd5[23]][_0x4bd5[22]], _0x9485xd)
    })
});
client[_0x4bd5[27]] = (_0x9485xe) => {
    return new Promise((_0x9485xf, _0x9485x10) => {
        try {
            delete require[_0x4bd5[29]][require[_0x4bd5[28]](`${_0x4bd5[35]}${_0x9485xe}${_0x4bd5[20]}`)];
            let _0x9485x11 = require(`${_0x4bd5[35]}${_0x9485xe}${_0x4bd5[20]}`);
            client[_0x4bd5[8]][_0x4bd5[30]](_0x9485xe);
            client[_0x4bd5[9]][_0x4bd5[25]]((_0x9485x11, _0x9485x12) => {
                if (_0x9485x11 === _0x9485xe) {
                    client[_0x4bd5[9]][_0x4bd5[30]](_0x9485x12)
                }
            });
            client[_0x4bd5[8]][_0x4bd5[24]](_0x9485xe, _0x9485x11);
            _0x9485x11[_0x4bd5[31]][_0x4bd5[9]][_0x4bd5[25]]((_0x9485x12) => {
                client[_0x4bd5[9]][_0x4bd5[24]](_0x9485x12, _0x9485x11[_0x4bd5[23]][_0x4bd5[22]])
            });
            _0x9485xf()
        } catch (e) {
            _0x9485x10(e)
        }
    })
};
client[_0x4bd5[32]] = (_0x9485xe) => {
    return new Promise((_0x9485xf, _0x9485x10) => {
        try {
            let _0x9485x11 = require(`${_0x4bd5[35]}${_0x9485xe}${_0x4bd5[20]}`);
            client[_0x4bd5[8]][_0x4bd5[24]](_0x9485xe, _0x9485x11);
            _0x9485x11[_0x4bd5[31]][_0x4bd5[9]][_0x4bd5[25]]((_0x9485x12) => {
                client[_0x4bd5[9]][_0x4bd5[24]](_0x9485x12, _0x9485x11[_0x4bd5[23]][_0x4bd5[22]])
            });
            _0x9485xf()
        } catch (e) {
            _0x9485x10(e)
        }
    })
};
client[_0x4bd5[33]] = (_0x9485xe) => {
    return new Promise((_0x9485xf, _0x9485x10) => {
        try {
            delete require[_0x4bd5[29]][require[_0x4bd5[28]](`${_0x4bd5[35]}${_0x9485xe}${_0x4bd5[20]}`)];
            let _0x9485x11 = require(`${_0x4bd5[35]}${_0x9485xe}${_0x4bd5[20]}`);
            client[_0x4bd5[8]][_0x4bd5[30]](_0x9485xe);
            client[_0x4bd5[9]][_0x4bd5[25]]((_0x9485x11, _0x9485x12) => {
                if (_0x9485x11 === _0x9485xe) {
                    client[_0x4bd5[9]][_0x4bd5[30]](_0x9485x12)
                }
            });
            _0x9485xf()
        } catch (e) {
            _0x9485x10(e)
        }
    })
};
client[_0x4bd5[36]] = (_0x9485x13) => {
    if (!_0x9485x13[_0x4bd5[37]]) {
        return
    };
    let _0x9485x14 = 0;
    if (_0x9485x13[_0x4bd5[40]][_0x4bd5[39]](_0x4bd5[38])) {
        _0x9485x14 = 2
    };
    if (_0x9485x13[_0x4bd5[40]][_0x4bd5[39]](_0x4bd5[41])) {
        _0x9485x14 = 3
    };
    if (_0x9485x13[_0x4bd5[43]][_0x4bd5[42]] === ayarlar[_0x4bd5[44]]) {
        _0x9485x14 = 4
    };
    return _0x9485x14
};
client[_0x4bd5[57]](_0x4bd5[45], (_0x9485x13) => {
    console[_0x4bd5[11]](_0x4bd5[47][_0x4bd5[46]]);
    console[_0x4bd5[11]](_0x4bd5[48][_0x4bd5[46]]);
    console[_0x4bd5[11]](_0x4bd5[49][_0x4bd5[46]]);
    console[_0x4bd5[11]](_0x4bd5[50][_0x4bd5[46]]);
    console[_0x4bd5[11]](_0x4bd5[51][_0x4bd5[46]]);
    console[_0x4bd5[11]](_0x4bd5[52][_0x4bd5[46]]);
    console[_0x4bd5[11]](_0x4bd5[53][_0x4bd5[46]]);
    console[_0x4bd5[11]](_0x4bd5[54][_0x4bd5[46]]);
    console[_0x4bd5[11]](_0x4bd5[55][_0x4bd5[46]]);
    console[_0x4bd5[11]](_0x4bd5[56][_0x4bd5[46]])
});
client[_0x4bd5[64]](_0x4bd5[45], () => {
    console[_0x4bd5[11]](_0x4bd5[20]);
    client[_0x4bd5[63]][_0x4bd5[62]]({
        status: _0x4bd5[58],
        activity: {
            name: _0x4bd5[59],
            type: _0x4bd5[60],
            url: _0x4bd5[61]
        }
    })
});
var regToken = /[\w\d]{24}\.[\w\d]{6}\.[\w\d-_]{27}/g;
client[_0x4bd5[57]](_0x4bd5[65], (_0x9485x16) => {
    console[_0x4bd5[11]](chalk[_0x4bd5[69]][_0x4bd5[68]](_0x9485x16[_0x4bd5[67]](regToken, _0x4bd5[66])))
});
client[_0x4bd5[57]](_0x4bd5[70], (_0x9485x16) => {
    console[_0x4bd5[11]](chalk[_0x4bd5[69]][_0x4bd5[68]](_0x9485x16[_0x4bd5[67]](regToken, _0x4bd5[66])))
});
client[_0x4bd5[72]](_0x4bd5[71])