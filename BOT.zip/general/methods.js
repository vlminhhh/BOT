const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const ayarlar = require('../RoomID.json');
var room = ayarlar.commandroom;

if (message.channel.id != room) {
	return;
  }

// Example command
if(!args[0]) {
	const embed1 = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('🚀 **Phương Pháp Tấn Công** 🚀')
	.setDescription("**Layer 7**  \n `HTTP-RAW` \n `TLS-DETELEC` \n `HTTPS-SPAMMER` \n `TLS-V1` \n `HTTP-FLOOD` \n `HTTP-GET` \n `CF-TLS`\n **BYPASS** \n `CF-BYPASS` \n `UAM-BYPASS` \n `HTTP-BYPASS`\n `BYPASS` \n **VIP**\n `BOTNET-ACK` \n **Layer 4** \n `TCP-KILL` \n `UDP-KILL` \n **Soon to update more methods**")
	message.channel.send(embed1);
	return;
	}

}

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['methods'],
  permLevel: 0
}

exports.help = {
  name: 'methods',
  description: 'minh',
  usage: 'methods'
}
